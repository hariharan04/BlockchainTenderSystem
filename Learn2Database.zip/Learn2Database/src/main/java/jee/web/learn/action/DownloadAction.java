package jee.web.learn.action;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.opensymphony.xwork2.ActionSupport;

import jee.web.learn.bean.EmpBean;
import jee.web.learn.dao.Admin;

public class DownloadAction extends ActionSupport {
	
	Admin dao = new Admin();
 public String execute() throws Exception {
	 
	 System.out.println("method for execute ");
	 
	 List<EmpBean> empList = dao.report("hariharan");
	 generateExcelReport(empList);
	 return "success";
 }
 
 
 public static void generateExcelReport(List<EmpBean> employeeList) {
     Workbook workbook = new XSSFWorkbook();
     Sheet sheet = workbook.createSheet("Employee Report");
     Row row = sheet.createRow(0);
     row.createCell(0).setCellValue("Serial Number");
     row.createCell(1).setCellValue("User Name");
     row.createCell(2).setCellValue("Email");
     row.createCell(3).setCellValue("Designation");
     row.createCell(4).setCellValue("Password");
     int rowNumber = 1;
     for (EmpBean employee : employeeList) {
         row = sheet.createRow(rowNumber++);
         row.createCell(0).setCellValue(employee.getSrNo());
         row.createCell(1).setCellValue(employee.getUname());
         row.createCell(2).setCellValue(employee.getUemail());
         row.createCell(3).setCellValue(employee.getUdeg());
         row.createCell(4).setCellValue(employee.getUpass());
         // Add more cells as needed for other properties

         // ...
     }

     try (FileOutputStream outputStream = new FileOutputStream("C:\\work\\employee_report.xlsx")) {
         workbook.write(outputStream);
     } catch (IOException e) {
         e.printStackTrace();
     }
 }
}

