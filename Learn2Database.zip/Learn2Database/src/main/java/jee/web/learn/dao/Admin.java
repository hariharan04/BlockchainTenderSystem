package jee.web.learn.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jee.web.learn.bean.EmpBean;

public class Admin {
	
	// method for create connection
	public static Connection getConnection() throws Exception {
		System.out.println("method for create connection");
		Class.forName("com.mysql.jdbc.Driver");
		try {
			return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/myschema", "root", "test");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	

	// method for fetch saved user data
	public List<EmpBean> report(String uname) throws SQLException, Exception {
		List<EmpBean> beanList = null;
		System.out.println("method for fetch saved user data");
		try {
			 String sql = "CALL GetUserDataByUname(?)";
	            PreparedStatement stmt = getConnection().prepareStatement(sql);
	            stmt.setString(1, uname);
	             beanList = new ArrayList<EmpBean>();
	            ResultSet rs = stmt.executeQuery();
	            int i = 0;
	            while (rs.next()) {
	                i++;
					EmpBean bean = new EmpBean();
					bean.setSrNo(i);
					bean.setUname(rs.getString("UNAME"));
					bean.setUemail(rs.getString("UEMAIL"));
					bean.setUpass(rs.getString("UPASS").replaceAll("(?s).", "*"));
					bean.setUdeg(rs.getString("UDEG"));
					beanList.add(bean);
	               
	        }
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
		System.out.println("method for fetch saved user data- END "+beanList.size());
		return beanList;
	}

	/*
	 CREATE OR REPLACE PROCEDURE GetEmployeeDataByUname (
    p_uname IN VARCHAR2,
    p_cursor OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN p_cursor FOR
    SELECT uname, uemail, upass, udeg
    FROM struts2crud
    WHERE uname = p_uname;
END GetEmployeeDataByUname;
/

<dependencies>
    <dependency>
        <groupId>com.oracle</groupId>
        <artifactId>ojdbc8</artifactId>
        <version>19.8.0.0</version> <!-- Use the version you installed -->
    </dependency>
</dependencies>


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OracleExample {
    public static void main(String[] args) {
        String jdbcUrl = "jdbc:oracle:thin:@localhost:1521:your_sid";
        String username = "your_username";
        String password = "your_password";
        String uname = "desired_username";

        try (Connection conn = DriverManager.getConnection(jdbcUrl, username, password)) {
            // Prepare the call to the stored procedure
            CallableStatement stmt = conn.prepareCall("{call GetEmployeeDataByUname(?, ?)}");
            stmt.setString(1, uname);
            stmt.registerOutParameter(2, OracleTypes.CURSOR);

            // Execute the stored procedure
            stmt.execute();

            // Retrieve the result set
            ResultSet rs = (ResultSet) stmt.getObject(2);

            while (rs.next()) {
                String retrievedUname = rs.getString("uname");
                String uemail = rs.getString("uemail");
                String upass = rs.getString("upass");
                String udeg = rs.getString("udeg");

                System.out.println("Username: " + retrievedUname);
                System.out.println("Email: " + uemail);
                System.out.println("Password: " + upass);
                System.out.println("Degree: " + udeg);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

	 */


}
